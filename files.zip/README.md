# SRM Team ROBOCON Workshops

A Batman-themed website for two workshops conducted by SRM Team **ROBOCON** at TP Ganeshan Auditorium.

| Workshop | Date | Time |
| --- | --- | --- |
| ShapeWaves | 27 September 2026 | 9:00 AM to 5:00 PM |
| ReactBits | 28 September 2026 | 9:00 AM to 5:00 PM |

**Venue:** TP Ganeshan Auditorium

**Club location:** SRM Team Robocon Lab, Aarush building, Main campus, SRMIST, Kattankulathur, Chennai 603203

## Files

- `index.html`: the whole website (HTML, CSS and JavaScript in one file)
- `README.md`: this file

## Run it locally

Double-click `index.html` to open it in your browser. Or, from this folder, run a small local server:

```bash
python3 -m http.server 8000
```

Then open <http://localhost:8000>.

## Add it to Git

```bash
git init
git add index.html README.md
git commit -m "Add ROBOCON workshops website"
git branch -M main
git remote add origin https://github.com/<your-username>/<your-repo>.git
git push -u origin main
```

## Put it online with GitHub Pages (optional)

1. Open the repository on GitHub, then go to **Settings**, then **Pages**.
2. Under **Build and deployment**, choose **Deploy from a branch**.
3. Pick the `main` branch and the `/ (root)` folder, then save.
4. After a minute, the site is live at `https://<your-username>.github.io/<your-repo>/`.

## Editing

- Workshop dates and times: search for `<time datetime=` in `index.html`.
- Workshop descriptions: edit the `<p>` inside each `<article class="card">`.
- Registration: add a button linking to your form inside `<div class="cta">`.
